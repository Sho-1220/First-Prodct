document.addEventListener('DOMContentLoaded', () => {
    // 要素の取得
    const startButton = document.getElementById('start-button');
    const restartButton = document.getElementById('restart-button');
    const resetHighScoreButton = document.getElementById('reset-highscore-button');
    const timeInput = document.getElementById('time');
    const difficultySelect = document.getElementById('difficulty');
    const settingsDiv = document.getElementById('settings');
    const gameDiv = document.getElementById('game');
    const timerElement = document.getElementById('timer');
    const targetElement = document.getElementById('target');
    const inputElement = document.getElementById('input');
    const feedbackElement = document.getElementById('feedback');
    const scoreElement = document.getElementById('score');
    const successSound = document.getElementById('success-sound');
    // 状態管理
    let words = [];
    let currentWord = '';
    let score = 0;
    let highScore = parseInt(localStorage.getItem('highScore')) || 0;
    let correctCount = 0;
    let mistakeCount = 0;
    let timeLeft = 60;
    let timerId = null;
    // 単語リストの取得
    const fetchWords = async () => {
        try {
            const response = await fetch('data/words.json');
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            words = data;
            updateScoreDisplay();
        } catch (error) {
            console.error('単語リストの読み込みに失敗:', error);
            targetElement.textContent = 'エラー: 単語リストを読み込めません';
            startButton.disabled = true;
        }
    };
    // ランダムな単語を取得（難易度に基づくフィルタリング）
    const getRandomWord = () => {
        if (words.length === 0) return '単語がありません';
        const selectedDifficulty = difficultySelect.value;
        let filteredWords;
        switch (selectedDifficulty) {
            case 'easy':
                filteredWords = words.filter(word => word.length <= 5);
                break;
            case 'medium':
                filteredWords = words.filter(word => word.length > 5 && word.length <= 8);
                break;
            case 'hard':
                filteredWords = words.filter(word => word.length > 8);
                break;
            default:
                filteredWords = words;
        }
        if (filteredWords.length === 0) return '該当する単語がありません';
        const index = Math.floor(Math.random() * filteredWords.length);
        return filteredWords[index];
    };
    // 新しいターゲット単語を設定
    const setNewTarget = () => {
        currentWord = getRandomWord();
        targetElement.textContent = currentWord;
        inputElement.value = '';
        feedbackElement.textContent = '';
        inputElement.focus();
    };
    // スコア表示の更新
    const updateScoreDisplay = () => {
        scoreElement.textContent = `スコア: ${score} | ハイスコア: ${highScore} | 正解数: ${correctCount} | ミス数: ${mistakeCount}`;
    };
    // スコアの更新
    const updateScore = () => {
        score++;
        correctCount++;
        if (score > highScore) {
            highScore = score;
            localStorage.setItem('highScore', highScore.toString());
        }
        updateScoreDisplay();
    };
    // タイマーの開始
    const startTimer = () => {
        timerElement.textContent = `制限時間: ${timeLeft}秒`;
        timerId = setInterval(() => {
            timeLeft--;
            timerElement.textContent = `制限時間: ${timeLeft}秒`;
            if (timeLeft <= 0) {
                clearInterval(timerId);
                endGame();
            }
        }, 1000);
    };
    // ゲームの終了
    const endGame = () => {
        inputElement.disabled = true;
        feedbackElement.textContent = `時間切れ！ 最終スコア: ${score}`;
        feedbackElement.className = 'incorrect';
        restartButton.classList.remove('hidden');
        resetHighScoreButton.classList.remove('hidden');
    };
    // ゲームのリセット
    const resetGame = () => {
        score = 0;
        correctCount = 0;
        mistakeCount = 0;
        const selectedTime = parseInt(timeInput.value);
        timeLeft = (!isNaN(selectedTime) && selectedTime > 0) ? selectedTime : 60;
        updateScoreDisplay();
        restartButton.classList.add('hidden');
        resetHighScoreButton.classList.add('hidden');
        inputElement.disabled = false;
    };
    // スタートボタンのクリックイベント
    startButton.addEventListener('click', () => {
        const selectedTime = parseInt(timeInput.value);
        if (isNaN(selectedTime) || selectedTime <= 0) {
            alert('有効な制限時間を入力してください。');
            return;
        }
        resetGame();
        settingsDiv.classList.add('hidden');
        gameDiv.classList.remove('hidden');
        setNewTarget();
        startTimer();
    });
    // 再スタートボタンのクリックイベント
    restartButton.addEventListener('click', () => {
        gameDiv.classList.add('hidden');
        settingsDiv.classList.remove('hidden');
    });
    // ハイスコアリセットボタンのクリックイベント
    resetHighScoreButton.addEventListener('click', () => {
        if (confirm('ハイスコアをリセットしますか？')) {
            highScore = 0;
            localStorage.setItem('highScore', highScore.toString());
            updateScoreDisplay();
            resetHighScoreButton.classList.add('hidden');
        }
    });
    // 入力フィールドの入力イベントハンドラー
    inputElement.addEventListener('input', () => {
        const inputText = inputElement.value.trim();
        if (inputText === currentWord) {
            feedbackElement.textContent = '正解！';
            feedbackElement.className = 'correct';
            updateScore();
            successSound.currentTime = 0;
            successSound.play();
            setTimeout(setNewTarget, 500); // 0.5秒後に新しい単語を表示
        } else if (currentWord.startsWith(inputText)) {
            feedbackElement.textContent = '進行中...';
            feedbackElement.className = 'progress';
        } else {
            if (inputText.length > 0) {
                feedbackElement.textContent = '間違い';
                feedbackElement.className = 'incorrect';
                mistakeCount++;
                updateScoreDisplay();
            } else {
                feedbackElement.textContent = '';
                feedbackElement.className = '';
            }
        }
    });
    // 初期化
    fetchWords();
});